package com.wipro.newdepartment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewdepartmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewdepartmentApplication.class, args);
	}

}
