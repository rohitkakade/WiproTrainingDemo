package com.discory.discoryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoryserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
